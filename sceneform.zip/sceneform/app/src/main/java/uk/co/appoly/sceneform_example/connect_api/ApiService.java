package uk.co.appoly.sceneform_example.connect_api;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;
import uk.co.appoly.sceneform_example.data_post_response.Category;
import uk.co.appoly.sceneform_example.data_post_response.Company;
import uk.co.appoly.sceneform_example.data_post_response.DataResponseLogin;
import uk.co.appoly.sceneform_example.data_post_response.BaseDataResponse;
import uk.co.appoly.sceneform_example.data_post_response.ResponseMemo;

public interface ApiService {

    @GET("api/v1/memo/list")
    Call<ResponseMemo> apiGetListMemo(
            @Header("Authorization") String authorHeader,
            @Query("username") String userName);

    @GET("/api/v1/category/list")
    Call<BaseDataResponse<List<Category>>> apiGetListCategory(
            @Header("Authorization") String authorHeader
    );

    @FormUrlEncoded
    @POST("api/v1/user/company-code")
    Call<BaseDataResponse<Company>> apiLoginFirst(
            @Field("app_token") String appToken,
            @Field("company_code") String companyCode
    );

    @FormUrlEncoded
    @POST("/api/v1/user/login")
    Call<DataResponseLogin> apiLogin(
            @Field("app_token") String appToken,
            @Field("username") String userName,
            @Field("password") String password,
            @Field("uuid") String uuid,
            @Field("kind") String kind
    );
}
