package uk.co.appoly.sceneform_example;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.UUID;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import uk.co.appoly.sceneform_example.connect_api.ApiService;
import uk.co.appoly.sceneform_example.connect_api.RetrofitClient;
import uk.co.appoly.sceneform_example.data_post_response.BaseDataResponse;
import uk.co.appoly.sceneform_example.data_post_response.DataResponseLogin;
import uk.co.appoly.sceneform_example.static_value.ValueStatic;

public class LoginSecondActivity extends AppCompatActivity implements
        View.OnClickListener {

    private ImageButton imbNextSecond;
    private ImageButton imbBackSecond;
    ApiService apiServices;
    private EditText edtId, edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_second);
        initComponent();
        imbNextSecond.setOnClickListener(this);
        imbBackSecond.setOnClickListener(this);
    }

    private void initComponent() {
        imbNextSecond = findViewById(R.id.imb_next_login);
        imbBackSecond = findViewById(R.id.imbBackLogin);
        edtId = findViewById(R.id.edit_id);
        edtPassword = findViewById(R.id.edit_password);
        RetrofitClient.setRetrofit(null);
        apiServices = RetrofitClient.getClient(ValueStatic.URL).create(ApiService.class);

    }

    private String getUUID() {
        return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private boolean textEmpty() {
        if (edtId.getText().toString().length() == 0) {
            Toast.makeText(this, "ID not empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (edtId.getText().toString().length() == 0) {
            Toast.makeText(this, "Password not empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void connectServer() {
        Call<DataResponseLogin> call;
        call = apiServices.apiLogin(
                ValueStatic.APP_TOKEN,
                edtId.getText().toString(),
                edtPassword.getText().toString(),
                getUUID(),
                "5");
        call.enqueue(new Callback<DataResponseLogin>() {
            @Override
            public void onResponse(Call<DataResponseLogin> call, Response<DataResponseLogin> response) {
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        if (response.body().getStatus().equals("success")) {
                            ValueStatic.TOKEN = response.body().getToken();
                            ValueStatic.userName = edtId.getText().toString();
                            goLocation();
                        } else {
                            Toast.makeText(getBaseContext(), "Connect Fail", Toast.LENGTH_SHORT).show();
                        }
                    }

                } else {
                    Toast.makeText(getBaseContext(), "Connect Fail", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DataResponseLogin> call, Throwable t) {

            }
        });
    }

    private void goLocation() {
        Intent intent = new Intent(this, LocationActivity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imb_next_login: {
                connectServer();
                break;
            }
            case R.id.imbBackLogin: {
                onBackPressed();
                break;
            }
        }
    }
}
