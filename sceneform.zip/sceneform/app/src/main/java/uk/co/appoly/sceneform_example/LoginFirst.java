package uk.co.appoly.sceneform_example;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import uk.co.appoly.sceneform_example.Utils.NetworkUtil;
import uk.co.appoly.sceneform_example.connect_api.ApiService;
import uk.co.appoly.sceneform_example.connect_api.RetrofitClient;
import uk.co.appoly.sceneform_example.data_post_response.BaseDataResponse;
import uk.co.appoly.sceneform_example.data_post_response.Company;
import uk.co.appoly.sceneform_example.static_value.ValueStatic;

public class LoginFirst extends AppCompatActivity implements
        View.OnClickListener {

    public static String URL = "https://luck-manager.aimap.jp/";
    private TextInputLayout textInputCompanyCode;
    private EditText editCompanyCode;
    private ImageButton imbNextFirst;
    ApiService apiService;
    private Company company;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_first);
        initComponent();
        imbNextFirst.setOnClickListener(this);
    }

    private void initComponent(){
        editCompanyCode = findViewById(R.id.edit_company_code);
        imbNextFirst = findViewById(R.id.btnNextFirst);
        apiService = RetrofitClient.getClient(URL).create(ApiService.class);
    }

    private void connectServer(){
        if(NetworkUtil.isNetworkConnected(this)){
            handleApiLogin();
        } else {
            Toast.makeText(this, "Check Connect Internet", Toast.LENGTH_SHORT).show();
        }
    }

    private void onConnectServer(){
        if(editCompanyCode.getText().toString().length()==0){
            Toast.makeText(this, "Company Code is empty", Toast.LENGTH_SHORT).show();
        } else {
            connectServer();
        }
    }

    private void handleApiLogin(){
        Call<BaseDataResponse<Company>> call;
        call = apiService.apiLoginFirst(
                ValueStatic.APP_TOKEN,
                editCompanyCode.getText().toString()
        );
        call.enqueue(new Callback<BaseDataResponse<Company>>() {
            @Override
            public void onResponse(Call<BaseDataResponse<Company>> call, Response<BaseDataResponse<Company>> response) {
                if(response.isSuccessful()) {
                    if (response.body() != null) {
                        if (response.body().getSuccess().equals("Exists company")) {
                            company = response.body().getData();
                            ValueStatic.URL = response.body().getData().getDomain();
                            onLogin();
                        } else {
                            Toast.makeText(getBaseContext(), "Company is Error \n Enter try company code", Toast.LENGTH_SHORT).show();
                        }
                    }
                }else {
                    Toast.makeText(getBaseContext(), "Connect Fail", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<BaseDataResponse<Company>> call, Throwable t) {
                Toast.makeText(getBaseContext(), "Connect Fail", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void onLogin(){
        Intent intent = new Intent(this, LoginSecondActivity.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnNextFirst: {
                onConnectServer();
            }
        }
    }
}
