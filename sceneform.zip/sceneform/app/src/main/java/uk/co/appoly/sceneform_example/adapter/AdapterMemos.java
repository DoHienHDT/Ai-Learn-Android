package uk.co.appoly.sceneform_example.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import uk.co.appoly.sceneform_example.R;
import uk.co.appoly.sceneform_example.data_post_response.Category;

public class AdapterMemos extends RecyclerView.Adapter<AdapterMemos.RecyclerViewHolder> {

    private List<Category> listCategory;
    public AdapterMemos(List<Category> data){
        listCategory = data;
    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_category, parent, false);
        return new RecyclerViewHolder(view);
}

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        holder.txtUserName.setText(listCategory.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return listCategory.size();
    }


    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        TextView txtUserName;
        public RecyclerViewHolder(View itemView) {
            super(itemView);
            txtUserName = (TextView) itemView.findViewById(R.id.text_category);
        }
    }
}
