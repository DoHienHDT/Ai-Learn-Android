package uk.co.appoly.sceneform_example.static_value;

public class ValueStatic {

    public static String URL = "https://luck-manager.aimap.jp/";
    public static String codeApp = "";
    public static String userName = "vtest1";
    public static String DEVICE_NAME="";
    public static String TOKEN="";
    public static String APP_TOKEN="6c17d2af3d615c155d90408a8d281fe0";
    public static int DISTANCE_MAX = 20000;
}
